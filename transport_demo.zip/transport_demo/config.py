"""Configuration constants for the transport allocation prototype."""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DB_PATH = Path(os.environ.get("TRANSPORT_DB_PATH", BASE_DIR / "transport_demo.db"))
RABBITMQ_URL = os.environ.get("TRANSPORT_RABBITMQ_URL", "amqp://guest:guest@localhost:5671/%2F")

EXCHANGE_NAME = os.environ.get("TRANSPORT_EXCHANGE", "x.commands")
EXCHANGE_COMMANDS = EXCHANGE_NAME  # friendly alias from the design doc
OFFER_ROUTING_KEY = os.environ.get("TRANSPORT_OFFER_ROUTING_KEY", "delhi.offer.create")
ROUTING_KEY_OFFER_CREATE = OFFER_ROUTING_KEY
OFFER_QUEUE = os.environ.get("TRANSPORT_OFFER_QUEUE", "q.delhi.offer")
QUEUE_OFFER_DELHI = OFFER_QUEUE

SUPERVISOR_POLL_INTERVAL_SEC = int(os.environ.get("TRANSPORT_SUPERVISOR_POLL", "5"))

SIM_ACCEPTANCE_RATE = float(os.environ.get("TRANSPORT_SIM_ACCEPTANCE_RATE", "0.0"))
