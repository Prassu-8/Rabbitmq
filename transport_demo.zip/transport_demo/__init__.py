"""Transport allocation prototype package."""
"""{
    "module":{
        "module_name":"transport_demo"
    }
}"""